create view viewodbernamista as
  select `d`.`ODBERMISTO`     AS `ODBERMISTO`,
         `d`.`OBEC`           AS `OBEC`,
         `d`.`ULICE`          AS `ULICE_ODBERNAMISTA`,
         `d`.`CP_CE`          AS `CP_CE`,
         `d`.`CISLODOMU`      AS `CISLODOMU`,
         `d`.`PARCELA`        AS `PARCELA`,
         `c`.`IDCISELPOD`     AS `IDCISELPOD`,
         `c`.`FIRMA`          AS `FIRMA`,
         `c`.`ULICE`          AS `ULICE_CISELPOD`,
         `c`.`PSC`            AS `PSC`,
         `c`.`MESTO`          AS `MESTO`,
         `v`.`CISLO_VODOMERU` AS `CISLO_VODOMERU`,
         `v`.`DATUM_MONTAZ`   AS `DATUM_MONTAZ`,
         `v`.`DRUH_VODOMERU`  AS `DRUH_VODOMERU`
  from ((`iwww`.`odbernamista` `d` left join `iwww`.`ciselpod` `c` on ((`c`.`IDCISELPOD` =
                                                                        `d`.`IDCISELPOD`))) left join `iwww`.`vodomery` `v` on ((
    `v`.`ID` = `d`.`ID_VODOMER`)));

