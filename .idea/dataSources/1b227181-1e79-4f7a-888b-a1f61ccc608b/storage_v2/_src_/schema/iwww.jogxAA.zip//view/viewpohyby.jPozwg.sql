create view viewpohyby as
  select `p`.`DATUM_POHYBU`   AS `DATUM_POHYBU`,
         `p`.`DRUH_POHYBU`    AS `DRUH_POHYBU`,
         `p`.`POPIS_POHYBU`   AS `POPIS_POHYBU`,
         `v`.`CISLO_VODOMERU` AS `CISLO_VODOMERU`,
         `v`.`DRUH_VODOMERU`  AS `DRUH_VODOMERU`,
         `c`.`IDCISELPOD`     AS `IDCISELPOD`
  from ((`iwww`.`vodomerypohyby` `p` left join `iwww`.`vodomery` `v` on ((`v`.`ID` =
                                                                          `p`.`ID_VODOMERY`))) left join `iwww`.`ciselpod` `c` on ((
    `c`.`IDCISELPOD` = `v`.`IDCISELPOD`)));

