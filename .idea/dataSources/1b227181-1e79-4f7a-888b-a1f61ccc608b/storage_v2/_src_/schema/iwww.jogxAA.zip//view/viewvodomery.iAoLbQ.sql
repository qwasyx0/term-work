create view viewvodomery as
  select `v`.`CISLO_VODOMERU`    AS `CISLO_VODOMERU`,
         `v`.`ROK_PRISTI_REVIZE` AS `ROK_PRISTI_REVIZE`,
         `v`.`DATUM_MONTAZ`      AS `DATUM_MONTAZ`,
         `v`.`DRUH_VODOMERU`     AS `DRUH_VODOMERU`,
         `o`.`OBEC`              AS `OBEC`,
         `o`.`ULICE`             AS `ULICE_ODBERNAMISTA`,
         `o`.`CP_CE`             AS `CP_CE`,
         `o`.`CISLODOMU`         AS `CISLODOMU`,
         `o`.`ODBERMISTO`        AS `ODBERMISTO`,
         `o`.`PARCELA`           AS `PARCELA`,
         `c`.`IDCISELPOD`        AS `IDCISELPOD`,
         `c`.`FIRMA`             AS `FIRMA`,
         `c`.`ULICE`             AS `ULICE_CISELPOD`,
         `c`.`PSC`               AS `PSC`,
         `c`.`MESTO`             AS `MESTO`
  from ((`iwww`.`vodomery` `v` left join `iwww`.`odbernamista` `o` on ((`o`.`ID` =
                                                                        `v`.`ID_ODBERMISTO`))) left join `iwww`.`ciselpod` `c` on ((
    `c`.`IDCISELPOD` = `v`.`IDCISELPOD`)));

