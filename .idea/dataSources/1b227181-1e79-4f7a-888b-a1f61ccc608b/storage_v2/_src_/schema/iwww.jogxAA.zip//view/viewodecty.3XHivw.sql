create view viewodecty as
  select `o`.`OBDOBI_OD`         AS `OBDOBI_OD`,
         `o`.`OBDOBI_DO`         AS `OBDOBI_DO`,
         `o`.`NOVY_STAV`         AS `NOVY_STAV`,
         `o`.`PREDCHOZI_STAV`    AS `PREDCHOZI_STAV`,
         `o`.`CASTKA_BEZ_DPH`    AS `CASTKA_BEZ_DPH`,
         `o`.`CASTKA_VCETNE_DPH` AS `CASTKA_VCETNE_DPH`,
         `v`.`CISLO_VODOMERU`    AS `CISLO_VODOMERU`,
         `v`.`ROK_PRISTI_REVIZE` AS `ROK_PRISTI_REVIZE`,
         `v`.`DRUH_VODOMERU`     AS `DRUH_VODOMERU`,
         `c`.`IDCISELPOD`        AS `IDCISELPOD`,
         `c`.`FIRMA`             AS `FIRMA`,
         `c`.`ULICE`             AS `ULICE_CISELPOD`,
         `c`.`PSC`               AS `PSC`,
         `c`.`MESTO`             AS `MESTO`,
         `d`.`ODBERMISTO`        AS `ODBERMISTO`,
         `d`.`TYP_SAZBY`         AS `TYP_SAZBY`,
         `d`.`OBEC`              AS `OBEC`,
         `d`.`ULICE`             AS `ULICE_ODBERNAMISTA`,
         `d`.`CP_CE`             AS `CP_CE`,
         `d`.`CISLODOMU`         AS `CISLODOMU`,
         `d`.`PARCELA`           AS `PARCELA`
  from (((`iwww`.`odectyvodomeru` `o` left join `iwww`.`vodomery` `v` on ((`v`.`ID` =
                                                                           `o`.`ID_VODOMER`))) left join `iwww`.`ciselpod` `c` on ((
    `c`.`IDCISELPOD` = `o`.`IDCISELPOD`))) left join `iwww`.`odbernamista` `d` on ((`d`.`ID` = `o`.`ID_ODBERMISTO`)));

